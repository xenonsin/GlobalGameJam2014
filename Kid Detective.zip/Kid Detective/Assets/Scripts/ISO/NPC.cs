﻿using UnityEngine;
using System.Collections;

public class NPC : MonoBehaviour {

	// Use this for initialization
	void Start () {
         /*
        iniParser parser = new iniParser();

       foreach (Transform child in transform)
        {
            parser.Set(child.name, "", "");
        }
        
        parser.Set("Mom", "Mom0", "You're an Asshole, son.", "She frowned.");
        parser.Set("Mom", "Mom1", "I'm Sorry.", "");
        parser.Set("Mom", "Mom2", "HI", "");
        parser.Set("Grandma", "g1", "Asshole.", "");
        parser.Save(IniFiles.PLAYER_DIALOG);
	*/
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
