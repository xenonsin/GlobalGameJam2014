﻿using UnityEngine;
using System.Collections;

public class DiningRoomToKitchen : MonoBehaviour {


    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (Player.talkedToDad && this.GetComponent<MofoDoor>().active)
            Application.LoadLevel("Kitchen");
    }
}
